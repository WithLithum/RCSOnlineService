INSTALLATION ARCHIVE FOR NAL RAGE
=====================================

Congratulations, you have successfully downloaded the NAL Rage. Now, you are about to install it.
Below is the detailed description on how to install NAL Rage.

LICENSE

This software is licensed under GNU General Public License version 3. At you opinion, you can select any later version
of the License if you are 'convoying' this software.

Definitions of 'later version' and 'convoying' are available in the license document.

DEPENDENCIES

Before you install NALRage, these dependencies must be installed.
 * A genuine copy of Grand Theft Auto V, in the latest supported version
    This is required for RAGE Plugin Hook, as it will refuse to load on illegal versions, as well as legitimate-but-outdated
    versions.

    Besure to regularly check for updates.

 * RAGE Plugin Hook.
    You can download it from https://ragepluginhook.net
    After downloaded, drag everything from that archive to the game folder.

    Besure to regularly check for updates, as it will be outdated each big patch.
 
 * RAGENativeUI.
    You can download it from alexguirre's RAGENativeUI repository in GitHub.
    To find it, search RAGENativeUI in GitHub.
    After downloaded, drag 'RAGENativeUI.dll' to the game folder.
    Requires the latest version. Do not use RAGENativeUI.dll included in any LSPDFR plugins.

 * Newtonsoft.Json
    Included in the archive.

INSTALLING
 * Purchase and install Grand Theft Auto V if you haven't.

 * Check all the dependencies. If lack of anything, install the dependencies.

 * Extract all files from the archive you have downloaded.
    This step is optional if your archive software support Drag 'n' drop or Copy & Paste.

 * Copy all the files from the "To Game Folder" directory to the install directory of the game.
    Do not just take the binary and drop it into plugins folder. If you do that, the plugin won't load.

 * Configure RAGE Plugin Hook properly.
    You might need to set the plugin timeout to 60000 milliseconds (one minute).

 * Start the game via RAGE plugin hook.
    * For Epic users, launch Grand Theft Auto V and RAGE Plugin Hook in sequence.
    * For retail (Rockstar) and Steam users, launch directly via RAGE Plugin Hook executable.

 * Press 'F4' (by default) to open the RAGE Plugin Hook console, then type "LoadPlugin NALRage.dll".
    You have to do this every time after the game is loaded. If you don't want to, add the command you type to the startup.rphs file.

IMPORTANT NOTICES ON PLAYING
 * You will have a flashlight and a pistol when the game begins.
    Use the flashlight to navigate out of the station.

 * If you don't like the blackout effect, you can turn it off.
    Press 'N' to open NAL Main Menu, and the first item is the Blackout check option.
    The option will be saved in your game savefile.
 
 * Your character will auto respawn if dead.

 * Please regularly save your game. This ensures you won't lost your game progress.

 * Watch out for the red circle blips on the minimap (just like GTA Online enemy blips).
    Killing these enimies will give you additional 30 NAL$, but be careful when proceeding as they are armed.
    You may have to use your pistol.
 
 * Do not kill too much NPCs.
    This will increase difficulty. Several game features varies on higher difficulties.

 * Watch out for the hungry status at right down corner.
    Do not sprint (holding down shift) if not required, as this will waste your hungry MUCH QUICKER.
    You are advised to use a vehicle for traveling.

    You can refill your hungry for a fee at the "Criminal Enterprise Starter Pack" blip on the minimap. They are very cheap.